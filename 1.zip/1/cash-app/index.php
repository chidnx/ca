<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="​One-click solution for your static? website., ​Hosting solution with benefits., What Clients Say, ​Purchase, ​Free, ​$9/month, ​$12/month, ​Get started with the simpliest static page">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Home</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Home.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.5.4, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "support",
		"sameAs": []
}</script>
    <meta name="theme-color" content="#4861df">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
  </head>
  <body data-home-page="Home.html" data-home-page-title="Home" class="u-body u-xl-mode"> 
    <section class="u-clearfix u-section-1" id="sec-a3f2">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-gutter-0 u-layout-wrap u-layout-wrap-1">
          <div class="u-layout" style="">
            <div class="u-layout-row" style="">
              <div class="u-align-left u-container-style u-layout-cell u-left-cell u-size-60 u-size-xs-60 u-white u-layout-cell-1" src="">
                <div class="u-container-layout u-container-layout-1">
                  <img class="u-image u-image-default u-image-1" src="images/Cash-App-logo_UmCXXUH.png" alt="" data-image-width="3840" data-image-height="2160">
                  <h1 class="u-custom-font u-font-montserrat u-text u-text-black u-text-1">For Help Call<br>
                  </h1>
                  <a href="tel:+18442486299" class="u-active-grey-90 u-border-none u-btn u-btn-round u-button-style u-custom-color-1 u-hover-grey-90 u-radius-8 u-text-active-white u-text-body-alt-color u-text-hover-white u-btn-1">+1 (844) 248-6299</a>
                  <img class="u-expanded-width u-image u-image-default u-image-2" src="images/cash-app-help-center-share.png" alt="" data-image-width="2400" data-image-height="1260">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-179565938-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-179565938-2');
</script>

    
